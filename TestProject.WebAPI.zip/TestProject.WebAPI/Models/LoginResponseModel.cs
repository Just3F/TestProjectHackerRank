﻿namespace TestProject.WebAPI.Models
{
    public class LoginResponseModel
    {
        public string AccessToken { get; set; }
        public string Username { get; set; }
    }
}
